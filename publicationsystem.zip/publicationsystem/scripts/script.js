// Base URL for your backend API
const API_URL = "http://localhost:5000/publications";

// DOM Elements
const publicationsContainer = document.getElementById("publications-container");
const publicationForm = document.getElementById("publication-form");
const searchForm = document.getElementById("search-form");
const searchResult = document.getElementById("search-result");

// Fetch and Display All Publications
async function fetchPublications() {
    try {
        const response = await fetch(API_URL); // GET request to fetch all publications
        if (!response.ok) throw new Error("Failed to fetch publications");
        const publications = await response.json();

        // Clear and render publications dynamically
        publicationsContainer.innerHTML = ""; // Clear existing content
        publications.forEach((pub) => {
            const pubDiv = document.createElement("div");
            pubDiv.classList.add("publication");
            pubDiv.innerHTML = `
                <h3>${pub.title} ${pub.openAccess ? '<span class="badge">Open Access</span>' : ""}</h3>
                <p>Authors: ${pub.authors.join(", ")}</p>
                <p>Category: ${pub.category}</p>
                <p>Publication Year: ${pub.year}</p>
                <div class="download-options">
                    <h4>Download Options:</h4>
                    ${pub.downloadLinks.pdf ? `<a href="${pub.downloadLinks.pdf}" class="download" target="_blank">PDF</a>` : ""}
                    ${pub.downloadLinks.epub ? `<a href="${pub.downloadLinks.epub}" class="download" target="_blank">EPUB</a>` : ""}
                    ${pub.downloadLinks.html ? `<a href="${pub.downloadLinks.html}" class="download" target="_blank">HTML</a>` : ""}
                </div>
            `;
            publicationsContainer.appendChild(pubDiv);
        });
    } catch (error) {
        console.error("Error fetching publications:", error);
        publicationsContainer.innerHTML = "<p>Failed to load publications. Please try again later.</p>";
    }
}

// Handle Adding a New Publication
publicationForm.addEventListener("submit", async (event) => {
    event.preventDefault(); // Prevent form from refreshing the page

    // Gather form data
    const newPublication = {
        title: document.querySelector("#title").value,
        authors: document.querySelector("#authors").value.split(",").map((author) => author.trim()),
        category: document.querySelector("#category").value,
        year: parseInt(document.querySelector("#year").value, 10),
        openAccess: document.querySelector("#open-access").checked,
        downloadLinks: {
            pdf: document.querySelector("#pdf").value,
        },
    };

    // POST request to add the publication
    try {
        const response = await fetch(`${API_URL}/add`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(newPublication),
        });

        if (!response.ok) throw new Error("Failed to add publication");

        // Refresh publications and reset the form
        fetchPublications();
        publicationForm.reset();
    } catch (error) {
        console.error("Error adding publication:", error);
        alert("Failed to add the publication. Please try again.");
    }
});

// Handle Searching for a Publication
searchForm.addEventListener("submit", async (event) => {
    event.preventDefault(); // Prevent form from refreshing the page

    const id = document.querySelector("#search-id").value; // Get publication ID

    try {
        const response = await fetch(`${API_URL}/${id}`); // GET request for the specific publication
        if (!response.ok) throw new Error("Publication not found");
        const publication = await response.json();

        // Display the searched publication
        searchResult.innerHTML = `
            <div class="publication">
                <h3>${publication.title} ${publication.openAccess ? '<span class="badge">Open Access</span>' : ""}</h3>
                <p>Authors: ${publication.authors.join(", ")}</p>
                <p>Category: ${publication.category}</p>
                <p>Publication Year: ${publication.year}</p>
                <div class="download-options">
                    <h4>Download Options:</h4>
                    ${publication.downloadLinks.pdf ? `<a href="${publication.downloadLinks.pdf}" class="download" target="_blank">PDF</a>` : ""}
                    ${publication.downloadLinks.epub ? `<a href="${publication.downloadLinks.epub}" class="download" target="_blank">EPUB</a>` : ""}
                    ${publication.downloadLinks.html ? `<a href="${publication.downloadLinks.html}" class="download" target="_blank">HTML</a>` : ""}
                </div>
            </div>
        `;
    } catch (error) {
        console.error("Error fetching publication:", error);
        searchResult.innerHTML = "<p>Publication not found. Please try again.</p>";
    }
});

// Fetch all publications when the page loads
fetchPublications();
