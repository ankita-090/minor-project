const mongoose = require("mongoose");

// Generate a new ObjectId
const objectId = new mongoose.Types.ObjectId();
console.log("Generated ObjectId:", objectId);
