const mongoose = require("mongoose");

const PublicationSchema = new mongoose.Schema({
    id: { type: Number, required: true },
    title: { type: String, required: true },
    authors: { type: [String], required: true },
    category: { type: String, required: true },
    year: { type: Number, required: true },
    openAccess: { type: Boolean, default: false },
    impactFactor: { type: Number },
    downloadLinks: {
        pdf: { type: String },
        epub: { type: String },
        html: { type: String }
    }
});

module.exports = mongoose.model("Publication", PublicationSchema);
