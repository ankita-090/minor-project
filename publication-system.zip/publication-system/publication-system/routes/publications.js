const express = require("express");
const router = express.Router();
const Publication = require("../models/Publication");

// Add a single or multiple publications
router.post("/add", async (req, res) => {
  try {
    const publications = req.body; // Accepts single object or an array of objects

    if (!Array.isArray(publications)) {
      // Handle single publication
      console.log("POST /publications/add - Request Body:", req.body);

      const newPublication = new Publication(req.body);
      const savedPublication = await newPublication.save();
      console.log("Publication saved successfully:", savedPublication);
      return res.status(201).json(savedPublication);
    }

    // Handle multiple publications (bulk insert)
    console.log("POST /publications/add - Multiple Publications:", publications);
    const savedPublications = await Publication.insertMany(publications);
    console.log("Publications saved successfully:", savedPublications);
    return res.status(201).json(savedPublications);
  } catch (err) {
    console.error("Error adding publication(s):", err);

    if (err.name === "ValidationError") {
      res.status(400).json({ message: "Validation Error", error: err.message });
    } else {
      res.status(500).json({ message: "Error adding publication(s)", error: err.message });
    }
  }
});

// Fetch all publications with pagination, sorting, and optional filters
router.get("/", async (req, res) => {
  try {
    console.log("GET /publications - Query Params:", req.query);
    const { page = 1, limit = 10, sortBy = "title", order = "asc", category, openAccess, impactFactor } = req.query;
    const filters = {};

    // Apply filters if provided
    if (category) filters.category = category;
    if (openAccess) filters.openAccess = openAccess === "true";
    if (impactFactor) filters.impactFactor = { $gte: Number(impactFactor) };

    // Fetch filtered, sorted, paginated results
    const publications = await Publication.find(filters)
      .sort({ [sortBy]: order === "asc" ? 1 : -1 }) // Sort by field, ascending or descending
      .skip((page - 1) * limit) // Skip documents for pagination
      .limit(Number(limit)); // Limit the number of documents per page

    // Count total documents for pagination metadata
    const total = await Publication.countDocuments(filters);

    // Respond with results and metadata
    res.status(200).json({
      publications,
      total,
      currentPage: Number(page),
      totalPages: Math.ceil(total / limit),
    });
  } catch (err) {
    console.error("Error fetching publications:", err);
    res.status(500).json({ message: "Error fetching publications", error: err.message });
  }
});

// Download publication files by format (e.g., PDF, EPUB, HTML)
router.get("/download/:format/:id", async (req, res) => {
  try {
    const { format, id } = req.params;
    console.log(`GET /download/${format}/${id} - Request received`);
    const publication = await Publication.findById(id);

    if (!publication || !publication.downloadLinks[format]) {
      console.error(`Download link not found for publication ID ${id} with format ${format}`);
      return res.status(404).json({ message: "Download link not found" });
    }

    console.log("Redirecting to download link:", publication.downloadLinks[format]);
    res.redirect(publication.downloadLinks[format]); // Redirect to the specified format
  } catch (err) {
    console.error("Error processing download request:", err);
    res.status(500).json({ message: "Error downloading file", error: err.message });
  }
});

module.exports = router; // Export the router for use in server.js
